%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% IN4393-16 Computer Vision %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Assignment 1 - Week 4.2 %%%%%%%%%%%%%%%%%%%
%%%%%%% Linear Filters: Gaussian and Derivatives %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% RUN VERSION 3 %%%%%%%%%%%%%%%%%%%%%%
%%% Author Info: Ali Nawaz, TU Delft, The Netherlands %%%% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Data Load
% Uncomment this part, load the data first, recomment and then run the whole script.
% Add the location of the image file
% Alternatively load the mat files provided.
% uiopen('add_file_location\zebra.png',1);
% uiopen('add_file_location\pn1.jpg',1);

pn1 = im2double(pn1); % image conversion from uint8 to jpg
zebra  = im2double(zebra); % image conversion from uint8 to jpg

%% Exercise 1,2 Designing 1D Gaussian Filter and Convolving an image with a 2D Gaussian
sigma_x = 0.05; % Sigma in x
sigma_y = 0.05; % Sigma in y

imOut = gaussianConv(pn1,sigma_x, sigma_y);
subplot(1,2,1)
imshow(pn1) % Actual picture
title('Before 2D Gaussian convolution')
subplot(1,2,2)
imshow(uint8(255*mat2gray(imOut))) % 2D Gaussian Convoluted 
title('After 2D Gaussian convolution')
%% Exercise 3 Comparision with Matlab's Gaussian Filter
sigma = sigma_x; % sigma_x
n = 1;
G = fspecial('gaussian',n,sigma); % Gaussian filter
imOut_m = conv2(pn1,G,'same'); % Built in Matlab function for applying Guassian filter

figure(2)
subplot(1,3,1);
imshow(pn1); % Actual picture
title('Before 2D Gaussian convolution');
subplot(1,3,2);
imshow(uint8(255*mat2gray(imOut))); % 2D Gaussian Convoluted 
title('After 2D Gaussian convolution');
subplot(1,3,3);
imshow(uint8(255*mat2gray(imOut))); % Application of Gaussian filter with the aid of built in Matlab function 
title('Matlab built-in Gaussian filter');
% Verified to be exactly the same

%% Exercise 4 Gaussian Derivative
Gd = gaussianDer(G, sigma);
%% Exercise 5 Gradient Magnitude and Orientation
sigma = 0.01;
% Magnitude and direction of gradient with constructed functions
[magnitude, orientation ] = gradmag(pn1,sigma);
% Magnitude and direction of gradient with built in Matlab function
% Verification of magnitude and orientation
[mag_v ori_v] = imgradient(pn1,'central');
figure(3)
subplot(1,3,1)
imshow(orientation, [-pi,pi]);
title('Generated gradient orientation')
colormap(hsv);
colorbar;
subplot(1,3,2)
imshow( (orientation - min(min(orientation)))./ ( max(max(orientation)) - min(min(orientation))), [0,1] );
title('Generated grad. orientation in binary')
colormap(hsv);
colorbar;
subplot(1,3,3)
imshow(ori_v, [0,1]);
colormap(hsv);
colorbar;
title('Gradient orientation with built in Matlab')

%% Quiver plot
[x,y] = meshgrid(1:1:300,1:1:300);
figure(4)
quiver(magnitude,orientation)
% quiver(x,y,magnitude,orientation) % Figure out correct implementation of
% quiver
grid on
title('Magnitude mesh, orientation values')
figure(5)
quiver(orientation, magnitude)
% quiver(x,y,orientation,magnitude) % Figure out correct implementation of
% quiver
grid on
title('Orientation mesh, magnitude values')

%% 5.3 Threshold on gradient magnitude so that the edge detection result in binary
mean_value = mean(mean(magnitude));
threshold = 0.04;
mag_bin = imbinarize(magnitude,threshold*mean_value);
figure(6)
subplot(1,3,1)
imshow(mag_bin)
title('Binarized gradient magnitude, generated')
colormap(hsv)
colorbar
subplot(1,3,2)
% imshow(magnitude, [ min(min(magnitude)), max(max(magnitude))])
imshow((magnitude - min(min(magnitude)))./ ( max(max(magnitude)) - min(min(magnitude))), [0,1] )
title('Normalized gradient magnitude, generated')
colormap(hsv)
colorbar
subplot(1,3,3)
imshow(mag_v)
title('Matlab built-in gradient magnitude')
colormap(hsv)
colorbar
%% 5.4 Image Derivative, check function file
%% 5.5 Impulse image behaviour
sigma = 0.3
impulse_image = zeros(300,300);
impulse_image(150,150) = 1;

image_0deg = conv2(gaussian(sigma),impulse_image); % Image convolved with 0 degree Gaussian
image_1deg = ImageDerivatives(impulse_image,sigma,'x'); % Image convolved with first degree Gaussian
image_2deg = ImageDerivatives(impulse_image,sigma,'xx'); % Image convolved with first degree Gaussian
image_mix_xy = ImageDerivatives(impulse_image,sigma,'xy'); % Image convolved with first degree Gaussian
image_mix_yx = ImageDerivatives(impulse_image,sigma,'yx'); % Image convolved with first degree Gaussian

figure(7)
subplot(2,3,1)
imshow(image_0deg)
title('Zero deg')
subplot(2,3,2)
imshow(image_1deg)
title('1 deg')
subplot(2,3,3)
imshow(image_2deg)
title('2 deg')
subplot(2,3,4)
imshow(image_mix_xy)
title('xy deg')
subplot(2,3,5)
imshow(image_mix_yx)
title('yx deg')



